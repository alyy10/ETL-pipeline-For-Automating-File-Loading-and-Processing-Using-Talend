CREATE TABLE `dataset` (
   `Order_Date` varchar(30) DEFAULT NULL,
   `Brand` varchar(9) DEFAULT NULL,
   `Sneaker` varchar(41) DEFAULT NULL,
   `Sale` varchar(5) DEFAULT NULL,
   `Retail` int DEFAULT NULL,
   `Profit` int DEFAULT NULL,
   `ProfitPercent` double(11,2) DEFAULT '0.00',
   `Buyer_Region` varchar(14) DEFAULT NULL,
   `filename` varchar(100) DEFAULT NULL,
   `loaddate` varchar(30) DEFAULT NULL
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci